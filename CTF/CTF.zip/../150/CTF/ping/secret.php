<?php
$usrnm='Admin';
$passwd='are_u_admin';
?>
